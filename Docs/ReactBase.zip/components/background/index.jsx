﻿import React from 'react';

class BackgroundPage extends React.Component {
    render() {
        return <span>Background Page Run</span>
    }
}

export default BackgroundPage;