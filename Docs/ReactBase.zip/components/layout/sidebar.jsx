﻿import React from 'react';
import { Link } from 'react-router-dom';

class SidebarMenu extends React.Component {
    render() {
        return <React.Fragment>
            <span>Menu</span>
            <Link to="/">
                Size
            </Link>
            <Link to="/background">
                Background
            </Link>
        </React.Fragment>
    }
}

export default SidebarMenu;