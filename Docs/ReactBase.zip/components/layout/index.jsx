﻿import React from 'react';
import { Route, Redirect, Switch } from 'react-router-dom';

import Sidebar from './sidebar';
import routes from './routes';
import qs from 'qs';

class LayoutPage extends React.Component {
    constructor(props) {
        super(props);
        const { location } = this.props;
        const options = qs.parse(location.search.replace("?", ""));

        this.state = {
            search: !!options.keyword == true && location.pathname == "/search" ? options.keyword : '',
        }

        this.routes = Object.values(routes);
    }

    render() {
        return <Switch>
            {
                this.routes.map(({ path, exact, ...layoutProps }) => (
                    <Route key={path} path={path} exact={exact} render={props => this.renderPage(layoutProps, props)} />
                ))
            }
        </Switch>
    }

    renderPage = ({ component, noLayout, noSidebar, title, cap, allowAnonymous }, routeProps) => {
        document.title = title;

        const { location, match, history } = this.props;

        component = React.createElement(component, { ...routeProps, search: this.state.search });

        return <React.Fragment>
            <Sidebar /> - {component}
        </React.Fragment>;
    }
}

export default LayoutPage;