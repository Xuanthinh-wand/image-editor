﻿import SizePage from '../size';
import BackgroundPage from '../background';

export default {
    home: {
        path: '/',
        exact: true,
        title: 'Size Page',
        component: SizePage,
    },
    size: {
        path: '/size',
        exact: true,
        title: 'Size Page',
        component: SizePage,
    },
    background: {
        path: '/background',
        exact: true,
        title: 'Background Page',
        component: BackgroundPage,
    },
}