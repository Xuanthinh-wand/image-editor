﻿import React from 'react';

class SizePage extends React.Component {
    render() {
        return <span>Size Page Run</span>
    }
}

export default SizePage;