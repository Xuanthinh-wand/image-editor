import { Layer } from './Layer';
export declare class FastLayer extends Layer {
    constructor(attrs: any);
}
