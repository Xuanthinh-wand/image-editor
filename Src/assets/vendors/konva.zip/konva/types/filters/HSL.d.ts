import { Filter } from '../Node';
export declare const HSL: Filter;
