import { Filter } from '../Node';
export declare const Pixelate: Filter;
