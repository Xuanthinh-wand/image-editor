import { Filter } from '../Node';
export declare const Brighten: Filter;
