import { Filter } from '../Node';
export declare const Grayscale: Filter;
