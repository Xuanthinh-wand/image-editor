import { Filter } from '../Node';
export declare const Sepia: Filter;
