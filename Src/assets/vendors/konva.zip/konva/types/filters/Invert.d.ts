import { Filter } from '../Node';
export declare const Invert: Filter;
