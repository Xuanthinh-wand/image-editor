import { Filter } from '../Node';
export declare const Contrast: Filter;
