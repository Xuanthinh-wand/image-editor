import { Filter } from '../Node';
export declare const Emboss: Filter;
