import { Filter } from '../Node';
export declare const Mask: Filter;
