import { Filter } from '../Node';
export declare const Noise: Filter;
