import { Filter } from '../Node';
export declare const RGB: Filter;
