declare var Konva: any;
